import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users=[];

  constructor(private http: Http) { }

  saveData(f){
    return this.http.put('https://first-try-http.firebaseio.com/user.json',f);
  }

  setData() {
    this.http.get('https://first-try-http.firebaseio.com/user.json')
    .subscribe(
      (response : Response) => {
        this.users=response.json();      
      }
    )


  }

  getData(){
    
    return this.users;
  }

  
}
