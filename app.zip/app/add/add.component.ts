import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import {Response} from '@angular/http'

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  users = [];

  constructor(private userService: UserService) { }

  myform = new FormGroup({
    'name': new FormControl('', Validators.required),
    'age' : new FormControl('', Validators.required),
    'email' : new FormControl('', [Validators.required,Validators.email]),
  });

  ngOnInit() {

      this.userService.setData();
      this.users=this.userService.getData(); 
      
        
  }

  onSubmit(){
    this.users.push(this.myform.value);
    this.userService.saveData(this.users).subscribe(
      (response: Response) => {
        console.log (response)
      }
      );
  }

}
